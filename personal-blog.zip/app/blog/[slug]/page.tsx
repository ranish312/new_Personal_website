import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Calendar, Clock, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  // In a real app, you would fetch the post data based on the slug
  const post = {
    title: `Blog Post Title for ${params.slug}`,
    date: new Date().toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
    readTime: "5 min read",
    content: `
      <p>This is the first paragraph of your blog post. It should introduce the topic and grab the reader's attention. Make it engaging and interesting to encourage people to continue reading.</p>
      
      <h2>First Section Heading</h2>
      
      <p>This is where you start diving into your content. Explain your main points clearly and concisely. Use examples to illustrate your points and make them more relatable to your readers.</p>
      
      <p>Continue developing your ideas in subsequent paragraphs. Make sure each paragraph focuses on a single idea or point to maintain clarity and flow.</p>
      
      <h2>Second Section Heading</h2>
      
      <p>In this section, you can explore another aspect of your topic. Perhaps you want to discuss challenges, solutions, or alternative perspectives.</p>
      
      <p>Use concrete examples and data to support your arguments. This helps build credibility and makes your content more valuable to readers.</p>
      
      <h2>Conclusion</h2>
      
      <p>Summarize the key points you've made in your post. Reinforce the main message you want readers to take away. You might also want to include a call to action or suggest further reading on the topic.</p>
    `,
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="font-bold text-xl">
            Ranish Ghimire
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/#about" className="text-sm font-medium transition-colors hover:text-primary">
              About
            </Link>
            <Link href="/#blog" className="text-sm font-medium transition-colors hover:text-primary">
              Blog
            </Link>
            <Link href="/#projects" className="text-sm font-medium transition-colors hover:text-primary">
              Projects
            </Link>
            <Link href="/#contact" className="text-sm font-medium transition-colors hover:text-primary">
              Contact
            </Link>
          </nav>
          <Button variant="outline" size="sm" className="md:hidden">
            Menu
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <article className="container max-w-3xl py-12 md:py-24 lg:py-32">
          <Link
            href="/blog"
            className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-8"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to all posts
          </Link>

          <div className="space-y-4">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">{post.title}</h1>

            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                <time dateTime={post.date}>{post.date}</time>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>{post.readTime}</span>
              </div>
              <Button variant="ghost" size="sm" className="ml-auto">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </div>

          <Image
            src={`/placeholder.svg?height=400&width=800&text=Blog+Post+Image`}
            width={800}
            height={400}
            alt="Blog post cover image"
            className="my-8 aspect-video rounded-lg object-cover"
          />

          <div
            className="prose prose-gray dark:prose-invert max-w-none"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />

          <div className="mt-16 border-t pt-8">
            <h2 className="text-2xl font-bold mb-4">Related Posts</h2>
            <div className="grid gap-6 md:grid-cols-2">
              {[1, 2].map((i) => (
                <div key={i} className="group flex flex-col space-y-2">
                  <Image
                    src={`/placeholder.svg?height=150&width=300&text=Related+Post+${i}`}
                    width={300}
                    height={150}
                    alt={`Related post ${i}`}
                    className="aspect-video rounded-lg object-cover transition-colors group-hover:border-primary"
                  />
                  <h3 className="text-lg font-medium group-hover:text-primary">Related Blog Post Title {i}</h3>
                  <p className="text-sm text-muted-foreground">
                    A brief description of this related post to entice readers to click.
                  </p>
                </div>
              ))}
            </div>
          </div>
        </article>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © {new Date().getFullYear()} Ranish Ghimire. All rights reserved.
          </p>
          <nav className="flex gap-4 sm:gap-6">
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              Privacy Policy
            </Link>
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              Terms of Service
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

